#ifndef __DEBUG
#define __DEBUG
int DEBUG_ON;
#endif
