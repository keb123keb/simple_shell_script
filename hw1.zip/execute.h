#ifndef __EXECUTE
#define __EXECUTE
int regular_expression_found;
char* re_temp_c;

int execute();
#endif
